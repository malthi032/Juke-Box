import java.sql.*;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Operations {
    public void addsong(song s){
        try{
            Operations op=new Operations();
            int artid=op.getArtist(s.getArtist_name(),s);
            int alid=op.getAlbum(s.getAlbum_name(),s);
            int gid=op.getgenre(s.getGname(),s);

        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
        PreparedStatement ps=con.prepareStatement("select songname from song where songname=? && artistid=? && albumid=? && gid=?");
        ps.setString(1,s.getSongname());
        ps.setInt(2,artid);
        ps.setInt(3,alid);
        ps.setInt(4,gid);
        ResultSet rs=ps.executeQuery();
        if(rs.next()==false) {
            PreparedStatement ps3 = con.prepareStatement("insert into song(songname,duration,artistid,albumid,gid) values(?,?,?,?,?)");
            ps3.setString(1, s.getSongname());
            ps3.setString(2, s.getDuration());
            ps3.setInt(3, artid);
            ps3.setInt(4, alid);
            ps3.setInt(5, gid);
            if (ps3.executeUpdate() == 1) {
                System.out.println("Insertion completed");
            }
        }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    int getArtist(String name,song s)
    {
        int artid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            //Statement st=con.createStatement();
            PreparedStatement ps=con.prepareStatement("select artistid from artist where artist_name=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                artid= rs.getInt(1);
            }
            else if(artid==0){
                artid= addartistid(s);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return artid;
    }

    int addartistid(song s)
    {
        int artid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into artist(artist_name,gender) values(?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getArtist_name());
            ps.setString(2, s.getGender());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    artid = rs.getInt(1);
                }
            }
        }
             catch (Exception e) {
                System.out.println(e.toString());
            }
        return artid;

    }
    int getAlbum(String name,song s)
    {
        int alid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select albumid from album where album_name=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                alid= rs.getInt(1);
            }
            else if(alid==0){
                alid= addalbumid(name,s);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return alid;
    }

    int addalbumid(String name,song s)
    {
        int alid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into album(album_name,relesdate) values(?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getAlbum_name());
            ps.setString(2, s.getR_date());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    alid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return alid;

    }
    int getgenre(String name,song s)
    {
        int gid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select gid from genre where gname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                gid= rs.getInt(1);
            }
            else if(gid==0){
                gid= addgenreid(name,s);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return gid;
    }

    int addgenreid(String name,song s)
    {
        System.out.println("11111"+name);
        int gid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into genre(gname) values(?)", Statement.RETURN_GENERATED_KEYS);
            System.out.println(s.getGname());
            ps.setString(1, s.getGname());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    gid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return gid;

    }
    public void searchSong(){
        System.out.println("Enter song name or album name or artist name or genre to Search");
        ArrayList<songview> list=new ArrayList<songview>();
        Scanner scan=new Scanner(System.in);
        String search=scan.next();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song1", "root", "malthi032");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from temp");
            while (rs.next())
            {
                songview sv=new songview(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5), rs.getString(6));
                list.add(sv);

            }

            Optional op=list.stream().filter(d->d.getGname().equalsIgnoreCase(search)||d.getAlbum_name().equalsIgnoreCase(search)||d.getArtist_name().equalsIgnoreCase(search)||d.getSongname().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
                list.stream().filter(d->d.getGname().equalsIgnoreCase(search)||d.getAlbum_name().equalsIgnoreCase(search)||d.getArtist_name().equalsIgnoreCase(search)||d.getSongname().equalsIgnoreCase(search)).sorted(Comparator.comparing(songview::getSongname)).forEach(e->System.out.println(e));

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }

    }
}
