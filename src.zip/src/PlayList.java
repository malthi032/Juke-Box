import java.sql.*;
import java.util.ArrayList;
import java.util.function.Consumer;

public class PlayList {
    private String plname,plduration;
    PlayList(String plname,String duration){
        this.plname=plname;
        this.plduration=duration;
    }

    public PlayList() {

    }

    ArrayList<String> getAllPlayList(){
        ArrayList<String> allplaylist =new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select plname from playlist");
            while (rs.next())
            {
               allplaylist.add(rs.getString(1));
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return allplaylist;
    }

    public void dispalyPlaylist(){

        System.out.println("---------------------------PlayList----------------------------");
        ArrayList<String> allplaylist =getAllPlayList();
        Consumer dis= c-> allplaylist.forEach(e->System.out.println(e));
        dis.accept(allplaylist);
        System.out.println("----------------------------------------------------------------");
    }
    public String getPlduration(){
        return plduration;
    }
    public String getPlname(){
        return plname;
    }

    public String toString(){
        return getPlname()+" : "+getPlduration();
    }
}
