import java.sql.*;
import java.util.*;
import java.util.function.Consumer;

public class SongDBOperation {

      public int addsong(song s){
          int sid=0;
          try{
            ArrayList<song> songlist=getAllSong();
           Optional<song> ifExist=songlist.stream().filter(d->(d.getGname().trim().equalsIgnoreCase(s.getGname()) &&
                    (d.getAlbum_name().equalsIgnoreCase(s.getAlbum_name())) &&
                    (d.getArtist_name().equalsIgnoreCase(s.getArtist_name())) &&
                    (d.getSongname().trim().equalsIgnoreCase(s.getSongname()))) ).findAny();
            if(ifExist.isPresent()) {
                System.out.println("Already Exists");
            }
            else
            {
                int artid=getArtist(s.getArtist_name(),s);
                int alid=getAlbum(s.getAlbum_name(),s);
                int gid=getgenre(s.getGname(),s);
                sid=addsong1(s,artid,alid,gid);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
          return sid;
    }

    public int addsong1(song s,int artid,int alid,int gid)
    {   int sid=0;
        try{
            sid=getsongid(s);
            if(sid==0) {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
                PreparedStatement ps3 = con.prepareStatement("insert into song(songname,duration,artistid,albumid,gid) values(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
                ps3.setString(1, s.getSongname());
                ps3.setString(2, s.getDuration());
                ps3.setInt(3, artid);
                ps3.setInt(4, alid);
                ps3.setInt(5, gid);
                if (ps3.executeUpdate() == 1) {
                    ResultSet rs = ps3.getGeneratedKeys();
                    if (rs.next()) {
                        sid = rs.getInt(1);
                    }
                    System.out.println("Insertion completed");
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
       return sid;
    }
    int getsongid(song s)
    {
        int sid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select songid from song where songname=?");
            ps.setString(1,s.getSongname());
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                sid=rs.getInt(1);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return sid;
    }
    int getArtist(String name,song s)
    {
        int artid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select artistid from artist where artist_name=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                artid=rs.getInt(1);
            }
            else if(artid==0){
                artid= addartistid(s);
                System.out.println("Artist"+artid);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return artid;
    }

    int addartistid(song s)
    {
        int artid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into artist(artist_name,gender) values(?,?)", Statement.RETURN_GENERATED_KEYS);
            System.out.println("-----helooo");
            ps.setString(1, s.getArtist_name());
            ps.setString(2, s.getGender());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    artid = rs.getInt(1);
                }
            }
        }
             catch (Exception e) {
                System.out.println(e.toString());
            }
        return artid;

    }
    int getAlbum(String name,song s)
    {
        int alid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select albumid from album where album_name=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                alid= rs.getInt(1);
            }
            else if(alid==0){
                alid= addalbumid(name,s);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return alid;
    }

    int addalbumid(String name,song s)
    {
        int alid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into album(album_name,relesdate) values(?,?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getAlbum_name());
            ps.setString(2, s.getR_date());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    alid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return alid;

    }
    int getgenre(String name,song s)
    {
        int gid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select gid from genre where gname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                gid= rs.getInt(1);
            }
            else if(gid==0){
                gid= addgenreid(name,s);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return gid;
    }

    int addgenreid(String name,song s)
    {
        int gid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into genre(gname) values(?)", Statement.RETURN_GENERATED_KEYS);
            System.out.println(s.getGname());
            ps.setString(1, s.getGname());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    gid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return gid;

    }

    public  ArrayList<song> getAllSong()
    {
        ArrayList<song> songlist = new ArrayList<song>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
        Statement st=con.createStatement();
        ResultSet rs=st.executeQuery("select * from temp1");
        while (rs.next())
        {
            song sv=new song(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(7),rs.getString(4), rs.getString(5),rs.getString(6));
            songlist.add(sv);
        }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return songlist;
    }
    public void display(ArrayList<song> d)
    {
        Consumer<ArrayList<song>> dis=c-> d.forEach(e->System.out.println(e));
        dis.accept(d);
    }
}
