import java.util.ArrayList;
import java.util.Scanner;

public class MainMethod1 {
    public static void main(String[] args) {
        //String narrator,tname,cname,pcname,epi_no,epi_name,duration;
        PodCast p=new PodCast("Gopi","Reality show","Vijay","Neeya Nana",1,"Politics","4:30");
        PodCast p1=new PodCast("Priyanka","Series","Priya","Priyamanavale",2,"twist-return","3:40");

        PodDbOperations op=new PodDbOperations();
        op.addPodcast(p);
        op.addPodcast(p1);

        PodcastCollectionOperation1 cop=new PodcastCollectionOperation1();
        //PodcastCollectionOperation cop=new PodcastCollectionOperation();

        System.out.println("------------------Menu------------------\n1.Add PodCast\n2.Search by podCast\n3.Search by celebrity" +
                "\n4.Search by type of Podcast\n5.Search by Narrator\n6.Search in general");
        Scanner scan=new Scanner(System.in);
        String narrator,tname,cname,pcname,epi_name,duration;
        int epi_no;
        int ch=scan.nextInt();
        switch (ch)
        {
            case  1:
            {
                System.out.println("Enter Narrator name ");
                narrator=scan.next();
                System.out.println("Enter Type of Podcast");
                tname=scan.next();
                System.out.println("Enter Celebrity Name");
                cname=scan.next();
                System.out.println("Enter Podcast Name");
                pcname=scan.next();
                System.out.println("Enter Episode Number");
                epi_no=scan.nextInt();
                System.out.println("Enter Episode name");
                epi_name=scan.next();
                System.out.println("Enter song Duration");
                duration=scan.next();
                PodCast ss=new PodCast(narrator,tname,cname,pcname,epi_no,epi_name,duration);
                op.addPodcast(ss);
                break;
            }
            case 2:
            {
                System.out.println("Enter Podcast to be Searched");
                String search = scan.next();
                ArrayList dis= (ArrayList) cop.searchByPodCast(op.getAllPodcast(),search);
                op.display(dis);
                break;
            }
            case 3:
            {
                System.out.println("Enter Celebrity to be Searched");
                String search = scan.next();
                ArrayList dis= (ArrayList) cop.searchByCelebrity(op.getAllPodcast(),search);
                op.display(dis);
                break;
            }
            case 4:
            {
                System.out.println("Enter Type of Podcast to be Searched");
                String search = scan.next();
                ArrayList dis= (ArrayList) cop.searchByType(op.getAllPodcast(),search);
                op.display(dis);
                break;
            }
            case 5:
            {
                System.out.println("Enter Narrator to be Searched");
                String search = scan.next();
                ArrayList dis= (ArrayList) cop.searchByNarrotor(op.getAllPodcast(),search);
                op.display(dis);
                break;
            }
            case 6:
            {
                System.out.println("Enter names to be Searched");
                String search = scan.next();
                ArrayList dis= (ArrayList) cop.searchinGeneral(op.getAllPodcast(),search);
                op.display(dis);
                break;
            }
        }



        //System.out.println("\n\n"+p);
    }
}
