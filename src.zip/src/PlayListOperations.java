import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

public class PlayListOperations {
    song s=new song();
    PodDbOperations db1=new PodDbOperations();
    SongDBOperation db=new SongDBOperation();
    int index=1;

    void addBySongName(List<song> sn1,String name,PlayList v){
        int sid=0,plid=0;
        Optional op=sn1.stream().filter(d-> d.getSongname().equalsIgnoreCase(name)).findAny();
        if(op.isPresent())
        {
            sid=getsid(name);
            plid=insertPlayList(sid,v.getPlname(),v.getPlduration());
        }
    }

    void addByAlbumName(List<song> sn1,song s,String alname,PlayList v,int n){
        int alid=0,plid=0,sid=0,artid=0,gid=0;
        Optional op=sn1.stream().filter(d-> d.getAlbum_name().equalsIgnoreCase(alname)).findAny();
        if(op.isPresent())
        {
                alid = db.getAlbum(alname, s);
                artid = db.getArtist(s.getArtist_name(), s);
                gid = db.getgenre(s.getGname(), s);
                sid=db.addsong1(s,artid,alid,gid);
                plid=insertPlayList(sid,v.getPlname(),v.getPlduration());
        }
    }

    void addByPodcastEpisode(List<PodCast> pc1,PodCast p,PlayList v)
    {
        int peid=0,plid=0,pid;
        Optional op=pc1.stream().filter(d-> d.getPcname().equalsIgnoreCase(p.getPcname())).findAny();
        if(op.isPresent())
        {
            pid=db1.getPodcast(p.getPcname(),p);
            peid=db1.addPodcast1(pid,p);
            plid=insertPlayList(peid,v.getPlname(),v.getPlduration());
        }
    }
    void addByCelebrity(List<PodCast> pc1,PodCast p,PlayList v)
    {
        int peid=0,plid=0,pid=0,cid=0,tid=0,nid=0;
        Optional op=pc1.stream().filter(d-> d.getCname().equalsIgnoreCase(p.getCname())).findAny();
        if(op.isPresent())
        {
            cid=db1.getCelebrity(p.getCname(),p);
            nid=db1.getNarrator(p.getNarrator(),p);
            tid=db1.getType(p.getTname(),p);
            pid=db1.getPodcast(p.getPcname(),p);
            if(db1.addPodcast(p)==0){
                peid=getpodcastepisodeid(p);
            }
            else {
                peid = db1.addPodcast1(pid,p);
            }
            plid=insertPlayList(peid,v.getPlname(),v.getPlduration());
        }
    }
    int insertPlayList(int sid,String plname,String dur) {
        int plid = 0;
        ArrayList<PlayListSongs>s1=new ArrayList<PlayListSongs>();
        ArrayList<PlayListPodCast>p1=new ArrayList<>();
        s1= (ArrayList<PlayListSongs>) getAllPlayListSongs();
        p1= (ArrayList<PlayListPodCast>) getAllPlayListEpisode();
        try {
            Optional op = s1.stream().filter(d -> d.getPlname().equalsIgnoreCase(plname)).findAny();
            Optional op1= p1.stream().filter(d -> d.getPlname().equalsIgnoreCase(plname)).findAny();
            if(op.isPresent()|| op1.isPresent())
            {
                System.out.println("Playlist already Exits");
                plid=getplid(plname);
                insertPlayListcontent(plid,sid,dur);
            }
             else {

                    Class.forName("com.mysql.cj.jdbc.Driver");
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
                    PreparedStatement ps = con.prepareStatement("insert into playlist(plname) values(?)", Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, plname);
                    if (ps.executeUpdate() == 1) {
                        ResultSet rs = ps.getGeneratedKeys();
                        if (rs.next()) {
                            plid = rs.getInt(1);
                            insertPlayListcontent(plid,sid,dur);
                        }
                    }
                }

       }
        catch(Exception e){
                System.out.println(e.toString());
            }
            return plid;
    }

    int getplid(String name)
    {
        int plid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select plid from playlist where plname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                plid= rs.getInt(1);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return plid;
    }
    void insertPlayListcontent(int plid,int tid,String dur)
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into playlistcon(plid,duration1,trackid) values(?,?,?)");
            ps.setInt(1,plid);
            ps.setString(2, dur);
            ps.setInt(3,tid);
            if (ps.executeUpdate() == 1) {
                System.out.println("Uploaded Successfully");
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    int getsid(String name)
    {
        int sid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select songid from song where songname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                sid= rs.getInt(1);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return sid;
    }
    int getpodcastepisodeid(PodCast p)
    {
        int peid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select peid from podcastepi where epi_name=?");
            ps.setString(1,p.getPcname());
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                peid= rs.getInt(1);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return peid;
    }

    List<PlayListSongs> getAllPlayListSongs()
    {
        ArrayList<PlayListSongs> plist = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from temp3");
            while (rs.next())
            {
                PlayListSongs sv=new PlayListSongs(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(9),rs.getString(6), rs.getString(7),rs.getString(8));
                plist.add(sv);
                //pmap.put(index,sv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return plist;
    }
    List<PlayListPodCast> getAllPlayListEpisode()
    {
        ArrayList<PlayListPodCast> plist = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from temp4");
            while (rs.next())
            {
                PlayListPodCast sv=new PlayListPodCast(rs.getString(1), rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getInt(7), rs.getString(8),rs.getString(9));
                plist.add(sv);
                //pmap.put(index,sv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return plist;
    }


    public void display(ArrayList<PlayListSongs> s,ArrayList<PlayListPodCast> p)
    {
        Consumer<ArrayList<PlayListSongs>> dis= c-> s.forEach(e->System.out.println(e));
        dis.accept(s);
        Consumer<ArrayList<PlayListPodCast>> dis1= d->p.forEach(k->System.out.println(k));
        dis1.accept(p);
    }
}
