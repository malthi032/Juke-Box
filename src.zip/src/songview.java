public class songview {
    private String artist_name,gender,album_name,gname,songname,duration;
    songview(String artist_name,String gender,String album_name,String gname,String songname,String duration)
    {
        this.artist_name=artist_name;
        this.gender=gender;
        this.album_name=album_name;
        this.gname=gname;
        this.songname=songname;
        this.duration=duration;
    }
    public String getArtist_name(){
        return artist_name;
    }
    public String getGender(){
        return gender;
    }
    public String getAlbum_name(){
        return album_name;
    }
    public String getGname(){
        return gname;
    }
    public String getSongname(){
        return songname;
    }
    public String getDuration(){
        return duration;
    }
    public String toString(){
        return getArtist_name()+" : "+getGender()+" : "+getAlbum_name()+" : "+getGname()+" : "+getSongname()+" : "+getDuration();
    }
}
