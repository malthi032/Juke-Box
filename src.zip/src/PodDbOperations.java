import java.sql.*;
import java.util.ArrayList;
import java.util.Optional;
import java.util.function.Consumer;

public class PodDbOperations {

    public int addPodcast(PodCast p){
        int peid=0;boolean res=false;
        try{
            //System.out.println(p.getTname());
            ArrayList<PodCast> podlist=getAllPodcast();
            Optional<PodCast> ifExist=podlist.stream().filter(d->(d.getPcname().equalsIgnoreCase(p.getPcname()))&&d.getTname().equalsIgnoreCase(p.getTname().trim()) &&
                    (d.getCname().equalsIgnoreCase(p.getCname().trim())) &&
                    (d.getNarrator().equalsIgnoreCase(p.getNarrator().trim()))).findAny();
            if(ifExist.isPresent()) {
                System.out.println("Already Exists");
            }
            else
            {
                int pid=getPodcast(p.getPcname(),p);
                peid=addPodcast1(pid,p);
                res=true;

            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return peid;
    }

    public int addPodcast1(int pid ,PodCast p)
    {
        int peid=0;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps3 = con.prepareStatement("insert into podcastepi(epi_no,epi_name,duration,pid) values(?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
            ps3.setInt(1, p.getEpi_no());
            ps3.setString(2, p.getEpi_name());
            ps3.setString(3, p.getDuration());
            ps3.setInt(4, pid);
            //ps3.setInt(5, gid);
            if (ps3.executeUpdate() == 1) {
                ResultSet rs=ps3.getGeneratedKeys();
                if(rs.next())
                {
                  peid=rs.getInt(1);
                  System.out.println("Insertion completed");
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return peid;
    }

    int getPodcast(String name,PodCast p)
    {
        int pid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select pid from podcast where pcname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                pid=rs.getInt(1);
            }
            else if(pid==0){
                pid= addPodcastid(p);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return pid;
    }
    int addPodcastid(PodCast p)
    {
        int pid=0;
        try{
            ArrayList<PodCast> pclist=getAllPodcast();
            Optional<PodCast> ifExist=pclist.stream().filter(d->(d.getTname().equalsIgnoreCase(p.getTname().trim()) &&
                    (d.getCname().equalsIgnoreCase(p.getCname().trim())) &&
                    (d.getNarrator().equalsIgnoreCase(p.getNarrator().trim())))).findAny();
            if(ifExist.isPresent()) {
                System.out.println("Already Exists");
            }
            else
            {
                int cid=getCelebrity(p.getCname(),p);
                int nid=getNarrator(p.getNarrator(),p);
                int tid=getType(p.getTname(),p);
                pid=addPodcastid1(cid,nid,tid,p);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return pid;
    }

    int addPodcastid1(int cid,int nid,int tid,PodCast p)
    {
        int pid=0;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps3 = con.prepareStatement("insert into podcast(pcname,nid,tid,cid) values(?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
            ps3.setString(1, p.getPcname());
            ps3.setInt(2, nid);
            ps3.setInt(3, tid);
            ps3.setInt(4, cid);

            if (ps3.executeUpdate() == 1) {
                ResultSet rs=ps3.getGeneratedKeys();
                if(rs.next())
                {
                    pid=rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return pid;
    }

    int getCelebrity(String name,PodCast p){
        int cid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select cid from celebrity where cname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                cid=rs.getInt(1);
            }
            else if(cid==0){
                cid= addCelebrity(p);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return cid;
    }
    int addCelebrity(PodCast p)
    {
        int cid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into celebrity(cname) values(?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, p.getCname());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    cid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return cid;
    }
    int getNarrator(String name,PodCast p){
        int nid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select nid from narrator where narrator=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                nid=rs.getInt(1);
            }
            else if(nid==0){
                nid= addNarrator(p);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return nid;
    }

    int addNarrator(PodCast p){
        int nid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into narrator(narrator) values(?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, p.getNarrator());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    nid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return nid;
    }
    int getType(String name,PodCast p){
        int tid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps=con.prepareStatement("select tid from type1 where tname=?");
            ps.setString(1,name);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                tid=rs.getInt(1);
            }
            else if(tid==0){
                tid= addType(p);
            }

        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return tid;
    }

    int addType(PodCast p){
        int tid=0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            PreparedStatement ps = con.prepareStatement("insert into type1(tname) values(?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, p.getTname());
            //System.out.println(p.getTname());
            if (ps.executeUpdate() == 1) {
                ResultSet rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    tid = rs.getInt(1);
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return tid;
    }

    public ArrayList<PodCast> getAllPodcast()
    {
        ArrayList<PodCast> podlist = new ArrayList<PodCast>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/song2", "root", "malthi032");
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select * from temp2");
            while (rs.next())
            {
                PodCast sv=new PodCast(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5), rs.getString(6),rs.getString(7));
                podlist.add(sv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return podlist;
    }
    public void display(ArrayList<PodCast> d)
    {
        Consumer<ArrayList<PodCast>> dis= c-> d.forEach(e->System.out.println(e));
        dis.accept(d);
    }
}
