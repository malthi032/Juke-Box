public class PlayListSongs extends PlayList {
        private String artist_name,gender,album_name,r_date,gname,duration;
        private String songname;
        PlayListSongs(){};
        PlayListSongs(String plname,String pldur,String artist_name,String gender,String album_name,String r_date,String gname,String songname,String duration)
        {
            super(plname,pldur);
            this.artist_name=artist_name;
            this.gender=gender;
            this.album_name=album_name;
            this.r_date=r_date;
            this.gname=gname;
            this.songname=songname;
            this.duration=duration;
        }
        public String getArtist_name(){
            return artist_name;
        }
        public String getR_date(){
            return r_date;
        }
        public String getGender(){
            return gender;
        }
        public String getAlbum_name(){
            return album_name;
        }
        public String getGname(){
            return gname;
        }
        public String getSongname(){
            return songname;
        }
        public String getDuration(){
            return duration;
        }
        public void setArtist_name(String artist_name){
            this.artist_name=artist_name;
        }
        public void setGender(String gender){
            this.gender=gender;
        }
        public void setAlbum_name(String album_name){
            this.album_name=album_name;
        }
        public void setGname(String gname){
            this.gname=gname;
        }
        public void setSongname(String songname){
            this.songname=songname;
        }
        public void setDuration(String duration){
            this.duration=duration;
        }

        public String toString(){
            return getPlname()+" :: "+getPlduration()+" :: Artist:"+getArtist_name()+" :: Artist-Gender:"+getGender()+" :: Album:"+getAlbum_name()+" :: Genre:"+getGname()+" :: Song:"+getSongname()+" :: Duration:"+getDuration()+" :: Released on:"+getR_date();
        }

}
