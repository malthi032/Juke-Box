import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class PodcastCollectionOperation {

    public List<PodCast> searchinGeneral(List<PodCast> podlist,String search){
        ArrayList<PodCast> s1=new ArrayList<>();
        try{
            Optional op=podlist.stream().filter(d->d.getCname().equalsIgnoreCase(search)||
                    d.getPcname().equalsIgnoreCase(search)||
                    d.getTname().equalsIgnoreCase(search)||
                    d.getNarrator().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
                s1= (ArrayList<PodCast>) podlist.stream().filter(d->d.getCname().equalsIgnoreCase(search)||
                        d.getPcname().equalsIgnoreCase(search)||
                        d.getTname().equalsIgnoreCase(search)||
                        d.getNarrator().equalsIgnoreCase(search)).sorted(Comparator.comparing(PodCast::getPcname)).collect(Collectors.toList());
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return s1;
    }

    public List<PodCast> searchByPodCast(List<PodCast> podlist,String search){
        ArrayList<PodCast> s1=new ArrayList<>();
        try{
            Optional op=podlist.stream().filter(d->d.getPcname().equalsIgnoreCase(search)||
                    d.getPcname().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
            {
                s1= (ArrayList<PodCast>) podlist.stream().filter(d->d.getCname().equalsIgnoreCase(search)||
                        d.getPcname().equalsIgnoreCase(search)).sorted(Comparator.comparing(PodCast::getPcname)).collect(Collectors.toList());
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return s1;
    }

    public List<PodCast> searchByCelebrity(List<PodCast> podlist,String search){
        ArrayList<PodCast> s1=new ArrayList<>();
        try{
            Optional op=podlist.stream().filter(d->d.getCname().equalsIgnoreCase(search)||
                    d.getCname().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
            {
                s1= (ArrayList<PodCast>) podlist.stream().filter(d->d.getCname().equalsIgnoreCase(search)||
                        d.getCname().equalsIgnoreCase(search)).sorted(Comparator.comparing(PodCast::getPcname)).collect(Collectors.toList());
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return s1;
    }

    public List<PodCast> searchByType(List<PodCast> podlist,String search){
        ArrayList<PodCast> s1=new ArrayList<>();
        try{
            Optional op=podlist.stream().filter(d->d.getTname().equalsIgnoreCase(search)||
                    d.getTname().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
                s1 = (ArrayList<PodCast>) podlist.stream().filter(d -> d.getTname().equalsIgnoreCase(search) ||
                        d.getTname().equalsIgnoreCase(search)).sorted(Comparator.comparing(PodCast::getPcname)).collect(Collectors.toList());
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return s1;
    }

    public List<PodCast> searchByNarrotor(List<PodCast> podlist,String search){
        ArrayList<PodCast> s1=new ArrayList<>();
        try{
            Optional op=podlist.stream().filter(d->d.getNarrator().equalsIgnoreCase(search)||
                    d.getNarrator().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
            {
                s1= (ArrayList<PodCast>) podlist.stream().filter(d->d.getNarrator().equalsIgnoreCase(search)||
                        d.getNarrator().equalsIgnoreCase(search)).sorted(Comparator.comparing(PodCast::getPcname)).collect(Collectors.toList());
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
        return s1;
    }
}



