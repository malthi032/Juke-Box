public class PlayListPodCast extends PlayList{
        //narrator.narrator,type1.tname,celebrity.cname,podcast.pcname,podcastepi.epi_no,podcastepi.epi_name,podcastepi.duration
        private String narrator,tname,cname,pcname,epi_name,duration;
        private int epi_no;
        PlayListPodCast(String plname,String pldur,String narrator, String tname, String cname, String pcname, int epi_no, String epi_name, String duration)
        {
            super(plname,pldur);
            this.narrator=narrator;
            this.tname=tname;
            this.cname=cname;
            this.pcname=pcname;
            this.epi_no=epi_no;
            this.epi_name=epi_name;
            this.duration=duration;
        }

        public PlayListPodCast() {

        }

        public String getNarrator(){
            return narrator;
        }
        public String getTname(){
            //System.out.println(tname);
            return tname;
        }
        public String getCname(){
            return cname;
        }
        public String getPcname(){
            return pcname;
        }
        public int getEpi_no(){
            return epi_no;
        }
        public String getEpi_name(){
            return epi_name;
        }
        public String getDuration(){
            return duration;
        }
        public void setEpi_name(String epi_name){
            this.epi_name = epi_name;
        }
        public void setEpi_no(int epi_no){
            this.epi_no=epi_no;
        }
        public void setDuration(String duration){
            this.duration=duration;
        }
        public void setNarrator(String narrator){
            this.narrator=narrator;
        }
        public void setTname(String tname){
            this.tname=tname;
        }
        public void setCname(String cname){
            this.cname=cname;
        }
        public void setPcname(String pcname){
            this.pcname=pcname;
        }

        //narrator.narrator,type1.tname,celebrity.cname,podcast.pcname,podcastepi.epi_no,podcastepi.epi_name,podcastepi.duration
        public String toString(){
            //System.out.println(getTname());
            return getPlname()+" :: "+getPlduration()+" :: Narrator:"+getNarrator()+" :: PodCast Type:"+getTname()+" :: Celebrity:"+getCname()+" :: Podcast:"+getPcname()+" :: Epi_no:"+getEpi_no()+" :: Episode:"+getEpi_name()+" :: Duration:"+getDuration();
        }

}
