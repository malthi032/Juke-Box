import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SongCollectionOperation {

    public ArrayList<song> searchSong(List<song> songlist, String search){
        ArrayList<song>s1=new ArrayList<>();
        try{
            Optional op=songlist.stream().filter(d->d.getGname().equalsIgnoreCase(search)||
                    d.getAlbum_name().equalsIgnoreCase(search)||
                    d.getArtist_name().equalsIgnoreCase(search)||
                    d.getSongname().equalsIgnoreCase(search)).findAny();
            if(op.isPresent())
                s1= (ArrayList<song>) songlist.stream().filter(d->d.getGname().equalsIgnoreCase(search)||
                        d.getAlbum_name().equalsIgnoreCase(search)||
                        d.getArtist_name().equalsIgnoreCase(search)||
                        d.getSongname().equalsIgnoreCase(search)).sorted(Comparator.comparing(song::getSongname)).collect(Collectors.toList());
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }
             return s1;
    }
}