import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Mainmethod {
    public static void main(String[] args) {
        song s=new song("Pradeep_Kumar","Male","Maragatha_Naanayam","2020-08-07","Melody","Nee kavithaigala","4:25");
        song s1=new song("Mano","Male","Nilave","1990-07-05","Rock","Nila","4:34");
        song s2=new song("chithra","female","vaanam","218-06-04","Jass","Vaaname","3:34");
        song s3=new song("chithra","female","venilave","218-06-04","Jass","Vaaname","3:34");
        song s4=new song("Mano","Male","Indian","1990-07-05","Rock","Kappal eri poiyachu","4;23");
        song s5=new song("Illayaraja","female","venmegam","218-06-04","Jass","Nilave va","3:23");



        //PodCast p0=new PodCast();

        SongDBOperation op=new SongDBOperation();
        SongCollectionOperation cop=new SongCollectionOperation();

        op.addsong(s);
        op.addsong(s1);
        op.addsong(s2);
        op.addsong(s3);
        op.addsong(s4);
        op.addsong(s5);

        PodCast p=new PodCast("Gopi","Reality show","Vijay","Neeya Nana",1,"Politics","4:30");
        PodCast p1=new PodCast("Priyanka","Series","Priya","Priyamanavale",2,"twist-return","3:40");

        PodDbOperations op1=new PodDbOperations();
        op1.addPodcast(p);
        op1.addPodcast(p1);

        PodcastCollectionOperation1 cop1=new PodcastCollectionOperation1();

        PlayListOperations pl=new PlayListOperations();
        Scanner scan=new Scanner(System.in);

        System.out.println("1.Song\n2.PodCast\n3.Playlist");
        int c=scan.nextInt();
        switch (c)
        {
            case 1:
            {
                String art,al,gender,rdate,g,sname,dur;
                System.out.println("---------Menu---------\n1. Add Song \n2.Search song");
                int n=scan.nextInt();
                switch (n)
                {
                    case  1:
                    {
                        System.out.println("Enter artist name ");
                        art=scan.next();
                        System.out.println("Enter Artist Gender");
                        al=scan.next();
                        System.out.println("Enter Album Name");
                        gender=scan.next();
                        System.out.println("Enter released date");
                        rdate=scan.next();
                        System.out.println("Enter genre");
                        g=scan.next();
                        System.out.println("Enter song name");
                        sname=scan.next();
                        System.out.println("Enter song Duration");
                        dur=scan.next();
                        song ss=new song(art,al,gender,rdate,g,sname,dur);
                        op.addsong(ss);
                        break;
                    }
                    case 2:
                    {
                        System.out.println("Enter song to be Searched");
                        String search = scan.next();
                        ArrayList dis=cop.searchSong(op.getAllSong(),search);
                        op.display(dis);
                        break;
                    }
                }
                break;
            }
            case 2:
            {
                System.out.println("------------------Menu------------------\n1.Add PodCast\n2.Search by podCast\n3.Search by celebrity" +
                        "\n4.Search by type of Podcast\n5.Search by Narrator\n6.Search in general");
                String narrator,tname,cname,pcname,epi_name,duration;
                int epi_no;
                int ch1=scan.nextInt();
                switch (ch1)
                {
                    case  1:
                    {
                        System.out.println("Enter Narrator name ");
                        narrator=scan.next();
                        System.out.println("Enter Type of Podcast");
                        tname=scan.next();
                        System.out.println("Enter Celebrity Name");
                        cname=scan.next();
                        System.out.println("Enter podcast Name");
                        pcname=scan.next();
                        System.out.println("Enter Episode Number");
                        epi_no=scan.nextInt();
                        System.out.println("Enter Episode name");
                        epi_name=scan.nextLine();
                        scan.nextLine();
                        System.out.println("Enter Duration");
                        duration=scan.nextLine();
                        PodCast ss=new PodCast(narrator,tname,cname,pcname,epi_no,epi_name,duration);
                        op1.addPodcast(ss);
                        break;
                    }
                    case 2:
                    {
                        System.out.println("Enter Podcast to be Searched");
                        String search = scan.next();
                        ArrayList dis= (ArrayList) cop1.searchByPodCast(op1.getAllPodcast(),search);
                        op1.display(dis);
                        break;
                    }
                    case 3:
                    {
                        System.out.println("Enter Celebrity to be Searched");
                        String search = scan.next();
                        ArrayList dis= (ArrayList) cop1.searchByCelebrity(op1.getAllPodcast(),search);
                        op1.display(dis);
                        break;
                    }
                    case 4:
                    {
                        System.out.println("Enter Type of Podcast to be Searched");
                        String search = scan.next();
                        ArrayList dis= (ArrayList) cop1.searchByType(op1.getAllPodcast(),search);
                        op1.display(dis);
                        break;
                    }
                    case 5:
                    {
                        System.out.println("Enter Narrator to be Searched");
                        String search = scan.next();
                        ArrayList dis= (ArrayList) cop1.searchByNarrotor(op1.getAllPodcast(),search);
                        op1.display(dis);
                        break;
                    }
                    case 6:
                    {
                        System.out.println("Enter names to be Searched");
                        String search = scan.next();
                        ArrayList dis= (ArrayList) cop1.searchinGeneral(op1.getAllPodcast(),search);
                        op1.display(dis);
                        break;
                    }
                }
                break;
            }
            case 3:
            {
                PlayList pl1=new PlayList();
                Audio au=new Audio();
                System.out.println("\n1.Show Playlist\n2.Create Playlist\n3.Play PlayList");
                int ch2=scan.nextInt();
                switch (ch2)
                {
                    case 1:
                        showPlaylist();
                        break;
                    case 2:
                        createPlaylist();
                        break;
                    case 3:
                        pl1.dispalyPlaylist();
                        System.out.println("Enter PlayList Names");
                        String n5=scan.next();
                        au.playSongs(n5);
                }

                break;
            }
        }


    }
    static void showPlaylist(){
        Scanner scan=new Scanner((System.in));
        SongDBOperation op=new SongDBOperation();
        PodDbOperations op1=new PodDbOperations();
        PlayListOperations pl=new PlayListOperations();
        System.out.println("\n1.View Contents\n2.Add Song/Podcast");
        int ch1=scan.nextInt();
        switch (ch1)
        {
            case 1:
            {
                ArrayList<PlayListSongs> pl1= (ArrayList<PlayListSongs>) pl.getAllPlayListSongs();
                ArrayList<PlayListPodCast>pl2= (ArrayList<PlayListPodCast>) pl.getAllPlayListEpisode();
                pl.display( pl1,pl2);
                break;
            }
            case 2:
            {
                System.out.println("1.Add by Song name\n2.Add by Album name\n3.Add by Episode\n4.Add by Celebrity");
                List<song>sn1=op.getAllSong();
                System.out.println(sn1);
                List<PodCast>pc1=op1.getAllPodcast();
                int ch2=scan.nextInt();
                switch (ch2)
                {
                    case 1:
                    {
                        System.out.println("Enter the song name");
                        String sname=scan.next();
                        System.out.println("Enter PlayList Name");
                        String plname=scan.next();
                        System.out.println("Enter PlayList duration");
                        String dur=scan.next();
                        PlayList v=new PlayList(plname,dur);
                        pl.addBySongName(sn1,sname,v);
                        break;
                    }
                    case 2:
                    {
                        song s0=new song();
                        System.out.println("Enter the Album name");
                        String alname=scan.next();
                        s0.setAlbum_name(alname);
                        System.out.println("Enter Number of Songs");
                        int n=scan.nextInt();
                        System.out.println("Enter PlayList Name");
                        String plname=scan.next();
                        System.out.println("Enter PlayList duration");
                        String dur=scan.next();
                        PlayList v=new PlayList(plname,dur);
                        int i=1;
                        while (i<=n)
                        {
                            System.out.println("Enter Song Name");
                            String sname=scan.next();
                            s0.setSongname(sname);
                            System.out.println("Enter Song Duration");
                            String dur1=scan.next();
                            s0.setDuration(dur1);
                            System.out.println("Enter Artist Name");
                            String artname=scan.next();
                            s0.setArtist_name(artname);
                            System.out.println("Enter Artist Gender");
                            s0.setGender(scan.next());
                            System.out.println("Enter genre");
                            s0.setGname(scan.next());
                            pl.addByAlbumName(sn1,s0,alname,v,n);
                            i++;
                        }
                        break;
                    }
                    case 3:
                    {
                        PodCast p11=new PodCast();
                        System.out.println("Enter Podcast Name");
                        String podc=scan.next();
                        p11.setPcname(podc);
                        System.out.println("Enter the Episode name");
                        String epiname=scan.next();
                        p11.setEpi_name(epiname);
                        System.out.println("Enter Episode Number");
                        p11.setEpi_no(scan.nextInt());
                        System.out.println("Enter Episode Duration");
                        p11.setDuration(scan.next());
                        System.out.println("Enter PlayList Name");
                        String plname=scan.next();
                        System.out.println("Enter PlayList duration");
                        String dur=scan.next();
                        PlayList v=new PlayList(plname,dur);
                        pl.addByPodcastEpisode(pc1,p11,v);
                        break;
                    }
                    case 4:
                    {
                        PodCast pc11=new PodCast();
                        System.out.println("Enter Celebrity Name");
                        String cname=scan.next();
                        pc11.setCname(cname);
                        System.out.println("Enter the Number of PodCast");
                        int nc=scan.nextInt(),i=1;
                        System.out.println("Enter PlayList Name");
                        String plname=scan.next();
                        System.out.println("Enter PlayList duration");
                        String dur=scan.next();
                        PlayList v=new PlayList(plname,dur);
                        while (i<=nc)
                        {
                            System.out.println("Enter Narrator");
                            String n=scan.next();
                            pc11.setNarrator(n);
                            System.out.println("Enter type of podcast");
                            String t=scan.next();
                            pc11.setTname(t);
                            System.out.println("Enter Podcast Name");
                            String pc=scan.next();
                            pc11.setPcname(pc);
                            System.out.println("Enter the Episode name");
                            String epiname=scan.next();
                            pc11.setEpi_name(epiname);
                            System.out.println("Enter Episode Number");
                            pc11.setEpi_no(scan.nextInt());
                            System.out.println("Enter Episode Duration");
                            pc11.setDuration(scan.next());
                            pl.addByCelebrity(pc1,pc11,v);
                            i++;
                        }
                    }
                }
            }

        }
    }
    static void createPlaylist(){
        showPlaylist();
    }

}
