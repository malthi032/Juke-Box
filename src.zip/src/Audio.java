import javax.sound.sampled.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class Audio {

    public void playSongs(String plname){
        Scanner scan=new Scanner(System.in);
       PlayListOperations pl=new PlayListOperations();
        List<PlayListSongs>songlist= (ArrayList<PlayListSongs>) pl.getAllPlayListSongs();
        ArrayList songs=new ArrayList();
        //List<String> songs= songlist.stream().map(e->songlist.get(e).getSongname());
        for (PlayListSongs i1:songlist)
        {
            String pl1=i1.getPlname();
            if(pl1.equalsIgnoreCase(plname))
            {
                songs.add(i1.getSongname());
            }
        }
        System.out.println("Do You want to play a particular song in playlist?(Y/N)");
        String ch=scan.next(),sname="";
        try {
            BufferedReader br = new BufferedReader(new FileReader("D:\\Wave 16\\jukebox\\src\\AudioNames1"));
            String name = br.readLine();
            switch (ch)
            {
                case "y":
                {    System.out.println("--------------------Songs in "+plname+"---------------------------");
                    Consumer dis= c-> songs.forEach(e->System.out.println(e));
                    dis.accept(songs);
                    System.out.println("--------------------------------------------------------------------");
                    System.out.println("Enter the Song Name");
                    sname=scan.next()+".wav";
                    while (name != null) {
                        String n1=name+"\\";
                        String spliti[] = n1.split("\\\\");
                        //System.out.println(spliti[4]);
                        if (spliti[5].equalsIgnoreCase(sname)) {
                            File file = new File(name);
                            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
                            Clip clip = AudioSystem.getClip();
                            clip.open(audioInputStream);

                            String res = "";

                            while (!res.equalsIgnoreCase("q")) {
                                System.out.println("(p)Play (s)Resume (r)Reset (n)next");
                                res = scan.next();

                                switch (res) {
                                    case ("p"):
                                        clip.start();
                                        break;
                                    case ("s"):
                                        clip.stop();
                                        break;
                                    case ("r"):
                                        clip.setMicrosecondPosition(0);
                                        break;
                                    case ("n"):
                                        clip.stop();
                                        res = "q";
                                }
                            }
                        }
                        name = br.readLine();
                    }
                    break;
                }
                case "n":
                {
                    while (name != null) {
                        String n1=name+"\\";
                        //System.out.println(n1);
                        String spliti[] = name.split("\\\\");
                        //System.out.println(spliti[3]);
                        if (spliti[4].equalsIgnoreCase(plname)) {
                            File file = new File(name);
                            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
                            Clip clip = AudioSystem.getClip();
                            clip.open(audioInputStream);

                            String res = "";

                            while (!res.equalsIgnoreCase("q")) {
                                System.out.println("(p)Play (s)Stop (r)Reset (n)next");
                                res = scan.next();

                                switch (res) {
                                    case ("p"):
                                        clip.start();
                                        break;
                                    case ("s"):
                                        clip.stop();
                                        break;
                                    case ("r"):
                                        clip.setMicrosecondPosition(0);
                                        break;
                                    case ("n"):
                                        clip.stop();
                                        res = "q";
                                        break;
                                }
                            }
                        }
                        name = br.readLine();
                    }
                    break;
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString());
        }

    }
}
